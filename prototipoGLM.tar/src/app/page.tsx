"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { INSTITUTIONS, getProgramsByInstitution } from "@/data/institutions-programs";
import { PredictionChart } from "@/components/prediction-chart";
import { LoadingSpinner } from "@/components/loading-spinner";
import { PredictionResult } from "@/types/prediction";

export default function Home() {
  const [institution, setInstitution] = useState<string>("");
  const [program, setProgram] = useState<string>("");
  const [year, setYear] = useState<string>("");
  const [semester, setSemester] = useState<string>("");
  const [availablePrograms, setAvailablePrograms] = useState<string[]>([]);
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>("");

  // Actualizar programas disponibles cuando cambia la institución
  useEffect(() => {
    if (institution) {
      const programs = getProgramsByInstitution(institution);
      setAvailablePrograms(programs);
      setProgram(""); // Resetear programa cuando cambia la institución
    } else {
      setAvailablePrograms([]);
      setProgram("");
    }
  }, [institution]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validaciones
    if (!institution || !program || !year || !semester) {
      setError("Por favor completa todos los campos");
      return;
    }

    const yearNum = parseInt(year);
    const currentYear = new Date().getFullYear();
    
    if (isNaN(yearNum) || yearNum < 2014 || yearNum > currentYear + 5) {
      setError(`El año debe estar entre 2014 y ${currentYear + 5}`);
      return;
    }

    if (semester !== "1" && semester !== "2") {
      setError("El semestre debe ser 1 o 2");
      return;
    }

    setError("");
    setLoading(true);
    
    try {
      const response = await fetch("/api/predict", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          institution,
          program,
          year: yearNum,
          semester: parseInt(semester),
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Error al realizar la predicción");
      }

      setPrediction(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error desconocido");
      setPrediction(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center py-8">
          <h1 className="text-4xl font-bold text-slate-800 mb-2">
            Predicción de Estudiantes Matriculados
          </h1>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Sistema de predicción utilizando modelo de regresión para estimar el número de estudiantes matriculados en programas universitarios de Colombia
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Formulario */}
          <Card>
            <CardHeader>
              <CardTitle>Parámetros de Predicción</CardTitle>
              <CardDescription>
                Selecciona la institución, programa, año y semestre para realizar la predicción
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Institución */}
                <div className="space-y-2">
                  <Label htmlFor="institution">Institución</Label>
                  <Select value={institution} onValueChange={setInstitution}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona una institución" />
                    </SelectTrigger>
                    <SelectContent>
                      {INSTITUTIONS.map((inst) => (
                        <SelectItem key={inst} value={inst}>
                          {inst}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Programa */}
                <div className="space-y-2">
                  <Label htmlFor="program">Programa</Label>
                  <Select 
                    value={program} 
                    onValueChange={setProgram}
                    disabled={!institution || availablePrograms.length === 0}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder={institution ? "Selecciona un programa" : "Primero selecciona una institución"} />
                    </SelectTrigger>
                    <SelectContent>
                      {availablePrograms.map((prog) => (
                        <SelectItem key={prog} value={prog}>
                          {prog}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Año y Semestre */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="year">Año</Label>
                    <Input
                      id="year"
                      type="number"
                      placeholder="Ej: 2024"
                      value={year}
                      onChange={(e) => setYear(e.target.value)}
                      min="2014"
                      max={new Date().getFullYear() + 5}
                    />
                    <p className="text-xs text-slate-500">
                      Entre 2014 y {new Date().getFullYear() + 5}
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="semester">Semestre</Label>
                    <Select value={semester} onValueChange={setSemester}>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccionar" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 (Primer semestre)</SelectItem>
                        <SelectItem value="2">2 (Segundo semestre)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Error */}
                {error && (
                  <Alert variant="destructive">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                {/* Botón */}
                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={loading || !institution || !program || !year || !semester}
                >
                  {loading ? <LoadingSpinner /> : "Predecir Estudiantes"}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Resultados */}
          <Card>
            <CardHeader>
              <CardTitle>Resultados de la Predicción</CardTitle>
              <CardDescription>
                {prediction 
                  ? "Predicción generada exitosamente" 
                  : "Completa el formulario para ver los resultados"
                }
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex flex-col items-center justify-center py-12">
                  <LoadingSpinner />
                  <p className="mt-4 text-slate-600">Realizando predicción...</p>
                </div>
              ) : prediction ? (
                <div className="space-y-6">
                  {/* Resultado numérico */}
                  <div className="text-center p-6 bg-blue-50 rounded-lg">
                    <p className="text-sm text-blue-600 mb-1">Estudiantes estimados</p>
                    <p className="text-4xl font-bold text-blue-800">
                      {prediction.predictedStudents}
                    </p>
                    <p className="text-sm text-blue-600 mt-2">
                      {prediction.institution} - {prediction.program}
                    </p>
                    <p className="text-sm text-blue-600">
                      {prediction.year} - Semestre {prediction.semester}
                    </p>
                  </div>

                  {/* Métricas del modelo */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 bg-green-50 rounded-lg">
                      <p className="text-sm text-green-600">Precisión (R²)</p>
                      <p className="text-xl font-bold text-green-800">
                        {(prediction.metrics.r2 * 100).toFixed(1)}%
                      </p>
                    </div>
                    <div className="p-4 bg-orange-50 rounded-lg">
                      <p className="text-sm text-orange-600">Error promedio</p>
                      <p className="text-xl font-bold text-orange-800">
                        {prediction.metrics.mae.toFixed(1)}
                      </p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 text-slate-400">
                  <p>Completa el formulario para ver los resultados</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Información del modelo */}
        <Card>
          <CardHeader>
            <CardTitle>Acerca del Modelo de Predicción</CardTitle>
            <CardDescription>
              Información sobre el modelo de regresión utilizado
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold mb-2">Modelo Utilizado</h3>
                <p className="text-sm text-slate-600 mb-4">
                  El sistema utiliza un modelo de regresión lineal para predecir el número de estudiantes matriculados 
                  basado en datos históricos de matrículas universitarias en Colombia.
                </p>
                
                <h3 className="font-semibold mb-2">Datos de Entrenamiento</h3>
                <ul className="text-sm text-slate-600 space-y-1">
                  <li>• Período: 2014 - 2024</li>
                  <li>• Instituciones: Corporación Universitaria Lasallista, Universidad de Antioquia</li>
                  <li>• Programas: +60 programas académicos</li>
                  <li>• Registros: +500 registros históricos</li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-semibold mb-2">Métricas del Modelo</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 bg-blue-50 rounded">
                    <span className="text-sm">Precisión (R²)</span>
                    <span className="font-semibold text-blue-800">94.4%</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-orange-50 rounded">
                    <span className="text-sm">Error Absoluto Medio</span>
                    <span className="font-semibold text-orange-800">58.4</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-green-50 rounded">
                    <span className="text-sm">Error Cuadrático Medio</span>
                    <span className="font-semibold text-green-800">153.5</span>
                  </div>
                </div>
                
                <p className="text-xs text-slate-500 mt-4">
                  * Las métricas pueden variar según la institución y programa seleccionados
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Gráfico */}
        {loading ? (
          <Card>
            <CardHeader>
              <CardTitle>Historial y Predicción</CardTitle>
              <CardDescription>
                Cargando datos para el gráfico...
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center h-96">
                <LoadingSpinner />
              </div>
            </CardContent>
          </Card>
        ) : prediction && (
          <Card>
            <CardHeader>
              <CardTitle>Historial y Predicción</CardTitle>
              <CardDescription>
                Gráfico que muestra el historial de matrículas y la predicción generada
              </CardDescription>
            </CardHeader>
            <CardContent>
              <PredictionChart data={prediction.historicalData} prediction={prediction} />
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}