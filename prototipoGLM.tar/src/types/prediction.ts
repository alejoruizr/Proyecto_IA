export interface HistoricalDataPoint {
  period: string;
  year: number;
  semester: number;
  totalStudents: number;
}

export interface ModelMetrics {
  mae: number;
  mse: number;
  rmse: number;
  r2: number;
}

export interface PredictionResult {
  institution: string;
  program: string;
  year: number;
  semester: number;
  predictedStudents: number;
  metrics: ModelMetrics;
  historicalData: HistoricalDataPoint[];
}