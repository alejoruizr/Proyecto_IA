"use client";

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Scatter } from "recharts";
import { HistoricalDataPoint, PredictionResult } from "@/types/prediction";

interface PredictionChartProps {
  data: HistoricalDataPoint[];
  prediction: PredictionResult;
}

export function PredictionChart({ data, prediction }: PredictionChartProps) {
  // Preparar datos para el gráfico
  const chartData = [
    ...data.map(point => ({
      period: point.period,
      year: point.year,
      semester: point.semester,
      students: point.totalStudents,
      type: "Histórico"
    })),
    {
      period: `${prediction.year}-${prediction.semester}`,
      year: prediction.year,
      semester: prediction.semester,
      students: prediction.predictedStudents,
      type: "Predicción"
    }
  ];

  // Custom tooltip
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-semibold">{`Periodo: ${label}`}</p>
          <p className="text-blue-600">{`Estudiantes: ${data.students}`}</p>
          <p className="text-sm text-gray-500">{`Tipo: ${data.type}`}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full h-96">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={chartData}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis 
            dataKey="period" 
            angle={-45}
            textAnchor="end"
            height={80}
            fontSize={12}
          />
          <YAxis />
          <Tooltip content={<CustomTooltip />} />
          <Legend />
          <Line
            type="monotone"
            dataKey="students"
            stroke="#2563eb"
            strokeWidth={2}
            dot={{ r: 4 }}
            activeDot={{ r: 6 }}
            name="Estudiantes Matriculados"
          />
          <Scatter
            data={chartData.filter(d => d.type === "Predicción")}
            fill="#dc2626"
            name="Predicción"
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}